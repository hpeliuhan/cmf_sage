# cmf_sage
This project is to enable cmf metadata logging for waggle sensor plugins. The kickstart  use case is based on the wildfire detetion plugin
